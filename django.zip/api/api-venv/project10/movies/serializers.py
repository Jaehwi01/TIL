from rest_framework import serializers
from .models import Movie, Genre, Score

class GenreSerializer(serializers.ModelSerializer):
    class Meta:
        model = Genre
        fields = ['id', 'name']
        
class MovieSerializer(serializers.ModelSerializer):
    class Meta:
        model =Movie
        fields = ['id', 'title', 'audience','poster_url','description','genre']
        
class GenreDataSerializer(serializers.ModelSerializer):
    movie_set = MovieSerializer(many=True)  # movie_set 이라는 변수에 무비의 모든정보가 담은 무비시리얼라이즈를 담고
    class Meta:
        model = Genre
        fields = ['id', 'name','movie_set']  #여기서 같이 표현
        
class ScoreSerializer(serializers.ModelSerializer):
    class Meta:
        model =Score
        fields = ['id', 'score','content']