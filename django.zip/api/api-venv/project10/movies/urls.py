from django.urls import path
from . import views

from rest_framework_swagger.views import get_swagger_view #스웨거 뷰를 위한 입력.

urlpatterns =[
    path('docs/',get_swagger_view(title='API Docs')),
    path('genre/', views.genre, name='genre'),    
    path('genre/<int:genre_id>/', views.genre_detail),
    path('movies/<int:movie_id>/', views.movie_detail),
    path('movies/<int:movie_id>/scores/', views.score_create),
    path('scores/<int:score_id>/',views.score_update_and_delete),
    path('movies/', views.movie),
]