from django.shortcuts import render, redirect, get_object_or_404
from .models import Genre, Movie, Score
from rest_framework.decorators import api_view
from .serializers import GenreSerializer, GenreDataSerializer,MovieSerializer,ScoreSerializer
from rest_framework.response import Response

# Create your views here.
def index(request):
    return render(request,'index.html')

@api_view(['GET']) # get 방식으로 
def genre(request):
    genres = Genre.objects.all() # 모든 장르 모델의 모든 오브젝트를 장르스에 담고
    serializer = GenreSerializer(genres, many=True) # 장르시리얼라이저에 장르스를 보내고 그것을 시리얼라이즈라는 변수에 저장. many=True 는 여러정보도 괜찮다는 의미
    return Response(serializer.data) # 시리얼라이즈라는 변수를 출력.

@api_view(['GET'])    
def movie(request):
    movies = Movie.objects.all()
    serializer = MovieSerializer(movies, many=True)
    return Response(serializer.data)
    
@api_view(['GET'])
def genre_detail(request, genre_id):
    genre = get_object_or_404(Genre, id=genre_id) #장르의 한 오브젝트를 장르변수에 담는다.
    serializer = GenreDataSerializer(genre) #위와 동일
    return Response(serializer.data)
    
@api_view(['GET'])
def movie_detail(request, movie_id):
    movie = get_object_or_404(Movie, id=movie_id)
    serializer = MovieSerializer(movie)
    return Response(serializer.data)
    
@api_view(['POST'])
def score_create(request, movie_id):
    serializer = ScoreSerializer(data=request.data)
    if serializer.is_valid(raise_exception=True): #raise_exception 에러뜨면 표시?
        serializer.save(movie_id=movie_id)
        return Response({'message':'작성되었습니다.'})
    else:
        return Response({'message':'뭐잘못햇어'})

@api_view(['PUT', 'DELETE'])
def score_update_and_delete(request, score_id):
    score = get_object_or_404(Score, id= score_id)
    if request.method =='PUT':
        serializer = ScoreSerializer(data=request.data, instance=score)
        if serializer.is_valid(raise_exception=True):
            serializer.save()
            return Response({'message':'수정완'})
            
    else:
        score.delete()
        return Response({'message':'삭제완'})